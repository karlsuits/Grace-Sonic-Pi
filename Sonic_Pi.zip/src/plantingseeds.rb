### Planting Seeds Starter

folder = "/Users/karl.suits/Desktop/project1/samples"

# Play a few sounds simply
sample folder, "dog.wav"
sleep 1
sample folder, "snare.wav"
sleep 1
sample folder, "whistle.wav"
sleep 2

# Try changing the sleep times or adding another sample!
# For example:
# sample folder, "traffic.wav"
# sleep 1
