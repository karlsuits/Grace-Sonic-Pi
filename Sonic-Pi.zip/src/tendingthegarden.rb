### Tending the Garden Starter

folder = "/Users/karl.suits/Desktop/project1/samples"

# Start with a simple rhythm
sample folder, "thud.wav"
sleep 1
sample folder, "snare.wav"
sleep 1
sample folder, "woo.wav", amp: 0.5

# Add some texture
sample folder, "street.wav", amp: 0.2
sleep 2

# Bring in a voice sample
sample folder, "yeah.wav", amp: 5
sleep 1 

# Layer something unexpected
sample folder, "crosswalk.wav", rate: 0.8, amp: 0.5
sleep 2

# Your turn! Add more samples below:
# sample folder, "bikechain.wav"
# sleep 1
# sample folder, "whistle.wav"
# sleep 1