# East Village Sound Sampler - Showcase Song
# Created for Grace Church Demo
# Karl Suits

folder = "/Users/karl.suits/Desktop/Samples/normalized"

use_bpm 90

live_loop :drums do
  sample folder, "thud.wav", amp: 1.5
  sleep 1
  sample folder, "snare.wav", amp: 1.2
  sleep 1
end

live_loop :skate, sync: :drums do
  with_fx :echo, phase: 0.75 do
    sample folder, "skate.wav", amp: 0.6, rate: 1
    sleep 4
  end
end

live_loop :voices, sync: :drums do
  with_fx :slicer, mix: 0.7 do
    sample folder, "voice.wav", amp: 1.3, rate: 0.9
    sleep 8
  end
end

live_loop :beats, sync: :drums do
  sample folder, "skate.wav", amp: 0.4, rate: 0.8
  sleep 2
  sample folder, "woo.wav", amp: 1
  sleep 2
end

# Occasional cheer for flavor
live_loop :cheer, sync: :drums do
  sleep 16
  sample folder, "yeah.wav", amp: 2
end

live_loop :dreamy_synth, sync: :drums do
  use_synth :hollow  # Dreamy, lush synth sound
  with_fx :reverb, mix: 0.8, room: 1 do
    play :e4, sustain: 2, release: 4, amp: 0.4
    sleep 4
    play :g4, sustain: 2, release: 4, amp: 0.4
    sleep 4
    play :d4, sustain: 2, release: 4, amp: 0.4
    sleep 4
    play :b3, sustain: 2, release: 4, amp: 0.4
    sleep 4
  end
end


live_loop :bassline, sync: :drums do
  if tick < 12 #first way to delay the start of a forever looping part
    sleep 1
  else
    use_synth :fm
    with_fx :lpf, cutoff: 90 do
      play :e2, sustain: 0.25, release: 0.3, amp: 0.7 #e2 : e is the note on the keyboard and 2 is the octave
      sleep 0.5
      play :e2, sustain: 0.25, release: 0.3, amp: 0.6
      sleep 0.5
      play :g2, sustain: 0.25, release: 0.3, amp: 0.6
      sleep 0.5
      play :b2, sustain: 0.25, release: 0.3, amp: 0.5
      sleep 1
      play :d2, sustain: 0.5, release: 0.5, amp: 0.7
      sleep 1
      play :b2, sustain: 0.25, release: 0.3, amp: 0.5
      sleep 1
    end
  end
end

set :start_arp, false  # Set an initial flag

live_loop :timer, sync: :drums do
  sleep 20  # a second way to delay the start of a forever looping part
  set :start_arp, true  # Flip the flag after 24 beats
  stop
end

live_loop :arp_riser, sync: :drums do
  if get(:start_arp)  # Only run when flag is true
    use_synth :blade  # Clean, glassy sound
    with_fx :reverb, room: 1, mix: 0.7 do
      with_fx :echo, phase: 0.375, mix: 0.4 do
        notes = [:e3, :g3, :b3, :d4, :g4, :b4]
        notes.each do |n|
          play n, sustain: 0.2, release: 0.6, amp: 0.1
          sleep 0.25
        end
      end
    end
    sleep 8  # Breath before looping
  else
    sleep 1  # Wait and check again
  end
end