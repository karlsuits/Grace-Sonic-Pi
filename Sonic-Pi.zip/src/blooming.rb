### Blooming Fully Starter

folder = "/Users/karl.suits/Desktop/project1/samples"

# Full creative remix challenge!

# Start your beat here:
live_loop :drums do
  sample folder, "thud.wav", amp: 3
  sleep 1
  sample folder, "snare.wav", amp: 3
  sleep 1
end

# Add city atmosphere
with_fx :echo do
  live_loop :city_sounds, sync: :drums do
    sample folder, "traffic.wav", amp: 0.3, rate: 1
    sleep 4
  end
end

# Street voices
with_fx :reverb do
  sample folder, "voice.wav", amp: 1.2
  sleep 8
end

# Background ambient layer
8.times do
  sample folder, "street.wav", amp: 0.3
  sleep 0.5
end

# Feel free to add more!
# sample folder, "woo.wav"
# sample folder, "yeah.wav"
# sample folder, "remotecar.wav"