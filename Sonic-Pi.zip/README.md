## Credits and Licensing

This project is licensed under the MIT License.

Original Sonic Pi code files and project structure © 2024 Karl Suits.  
Audio samples in the "loops" and "505" folders were downloaded freely from external sources and may be subject to additional copyright restrictions — please verify before reusing these samples commercially.  
Sonic Pi software installation is external and provided by https://sonic-pi.net under its own licensing terms.

Feel free to remix, adapt, and build upon this project for educational or creative purposes!